//
//  TestApp.swift
//  Test
//
//  Created by Guilherme on 05/09/22.
//

import SwiftUI

@main
struct TestApp: App {
        let persistenceController = PersistenceController.shared
        
        var body: some Scene {
            WindowGroup {
                SwiftUIView_Previews.previews
                
            }
        }
    
    
    }
